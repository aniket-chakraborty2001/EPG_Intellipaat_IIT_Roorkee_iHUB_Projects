-- Use the assignment database
USE ASSIGNMENTS;

-- Check for the JomatoSales table
SELECT TOP 10 * FROM JomatoSales;
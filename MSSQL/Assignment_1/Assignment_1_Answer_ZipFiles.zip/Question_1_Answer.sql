-- Use the assignments database
USE ASSIGNMENTS;

--TASK TO PERFORM IN ASSIGNMENT 1:
-- 1) Insert another record in the Orders table
	INSERT INTO Orders VALUES
	(5004, 3781, 104, '2019-02-20', 865);
	SELECT * FROM Orders;




